package com.baomidou.mybatisplus.samples.mysql;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysqlApplication {

}
