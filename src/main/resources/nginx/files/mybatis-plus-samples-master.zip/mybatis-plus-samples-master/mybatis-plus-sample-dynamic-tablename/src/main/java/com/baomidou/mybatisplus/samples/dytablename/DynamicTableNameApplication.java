package com.baomidou.mybatisplus.samples.dytablename;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DynamicTableNameApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynamicTableNameApplication.class, args);
	}
}
