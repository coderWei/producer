/**
 * Copyright (C), 2005-2019, 深圳市珍爱网信息技术有限公司
 */

package com.baomidou.mybatisplus.samples.reduce.springmvc.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Description: TODO
 * @Author: alan2lin
 * @Date: 2019/7/4 22:50
 * @Version V1.0
 */
public interface MyBaseMapper<T> extends BaseMapper<T> {
}
