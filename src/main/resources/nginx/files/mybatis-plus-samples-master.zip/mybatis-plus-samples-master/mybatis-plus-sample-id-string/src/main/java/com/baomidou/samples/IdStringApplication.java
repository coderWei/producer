package com.baomidou.samples;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdStringApplication {

    public static void main(String[] args) {
        SpringApplication.run(IdStringApplication.class, args);
    }
}
