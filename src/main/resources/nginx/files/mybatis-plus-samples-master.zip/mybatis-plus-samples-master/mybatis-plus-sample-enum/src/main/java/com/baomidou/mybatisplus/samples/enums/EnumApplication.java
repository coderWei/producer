package com.baomidou.mybatisplus.samples.enums;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnumApplication {

    public static void main(String[] args) {
        SpringApplication.run(EnumApplication.class, args);
    }
}

